<?php
defined('ABSPATH') || exit;
?>

<?php get_template_part('sidebar-templates/sidebar', 'footerfull'); ?>

<footer class="bf-footer" role="contentinfo" aria-label="Site footer">
	<div class="container">
		<div class="bf-footer-grid footer-navigation">
			<div class="bf-footer-brand">
				<a href="/" class="bf-logo" aria-label="Botphonic – Back to homepage">
					<img src="https://botphonic.ai/wp-content/uploads/2025/04/Botphonic-logo-1.svg" alt="Botphonic" width="160" height="auto" loading="lazy">
				</a>
				<p class="bf-desc">AI voice agents that answer, book and follow up on every business call, in 50+ languages.</p>
				<ul class="bf-social" role="list" aria-label="Botphonic on social media">
					<li>
						<a href="https://www.linkedin.com/company/botphonic/" target="_blank" rel="noopener noreferrer" aria-label="Follow Botphonic on LinkedIn" class="bf-social-link">
							<svg aria-hidden="true" focusable="false" width="20" height="20" fill="currentColor" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg">
								<path d="M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z" />
							</svg>
						</a>
					</li>

					<li>
						<a href="https://x.com/botphonic" target="_blank" rel="noopener noreferrer" aria-label="Follow Botphonic on X (Twitter)" class="bf-social-link">
							<svg aria-hidden="true" focusable="false" width="20" height="20" fill="currentColor" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
								<path d="M389.2 48h70.6L305.6 224.2 487 464H345L233.7 318.6 106.5 464H35.8L200.7 275.5 26.8 48H172.4L272.9 180.9 389.2 48zM364.4 421.8h39.1L151.1 88h-42L364.4 421.8z" />
							</svg>
						</a>
					</li>

					<li>
						<a href="https://facebook.com/botphonic" target="_blank" rel="noopener noreferrer" aria-label="Follow Botphonic on Facebook" class="bf-social-link">
							<svg aria-hidden="true" focusable="false" width="20" height="20" fill="currentColor" viewBox="0 0 320 512" xmlns="http://www.w3.org/2000/svg">
								<path d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z" />
							</svg>
						</a>
					</li>

					<li>
						<a href="https://www.instagram.com/botphonicai/" target="_blank" rel="noopener noreferrer" aria-label="Follow Botphonic on Instagram" class="bf-social-link">
							<svg aria-hidden="true" focusable="false" width="20" height="20" fill="currentColor" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg">
								<path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z" />
							</svg>
						</a>
					</li>

					<li>
						<a href="https://www.youtube.com/@BotPhonic" target="_blank" rel="noopener noreferrer" aria-label="Watch Botphonic on YouTube" class="bf-social-link">
							<svg aria-hidden="true" focusable="false" width="20" height="20" fill="currentColor" viewBox="0 0 576 512" xmlns="http://www.w3.org/2000/svg">
								<path d="M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z" />
							</svg>
						</a>
					</li>

				</ul>
			</div>


			<?php for ($i = 2; $i <= 8; $i++) : ?>
			<?php if (is_active_sidebar("footer-column-{$i}")) : ?>
			<div class="bf-footer-links footer-column-<?php echo esc_attr($i); ?>">
				<?php dynamic_sidebar("footer-column-{$i}"); ?>
			</div>
			<?php endif; ?>
			<?php endfor; ?>

		</div>
	</div>

	<div class="bf-footer-bottom" role="contentinfo" aria-label="Footer legal information">
		<div class="container">
			<span class="bf-copyright">
				&copy; <?php echo esc_html(date('Y')); ?> Botphonic. All rights reserved.
			</span>
			<nav class="bf-bottom-nav" aria-label="Legal links">
				<a href="/privacy-policy/">Privacy Policy</a>
				<span aria-hidden="true">&middot;</span>
				<a href="/terms-condition/">Terms &amp; Conditions</a>
				<span aria-hidden="true">&middot;</span>
				<a href="/security/">Security</a>
				<span aria-hidden="true">&middot;</span>
				<a href="/sitemap/">Sitemap</a>
			</nav>
		</div>
	</div>

</footer>

</div>

<script>
	window.myData = window.myData || {};
	window.myData.isUserLoggedIn = <?php echo wp_json_encode(is_user_logged_in()); ?>;
</script>

<?php wp_footer(); ?>
<script src="https://analytics.ahrefs.com/analytics.js" data-key="eVKNLo7Zd3e7F3IfEVWNpw" async></script>
</body>

</html>