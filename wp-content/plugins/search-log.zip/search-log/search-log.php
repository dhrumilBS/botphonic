<?php
/*
Plugin Name: Search Log
Description: Logs user searches in WordPress, including search term, IP address, location, and country.
Version: 1.0.0
Author: wordpressdev bigscal
Author URI: https://bigscal.com/
Text Domain: search-log
Domain Path: /languages
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/

// 1. Create table on activation
function my_create_search_logs_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'search_logs';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        search_term text NOT NULL,
        search_slug varchar(255) DEFAULT '' NOT NULL,
        ip_address varchar(50) NOT NULL,
        user_id bigint(20) DEFAULT 0 NOT NULL,
        user_name varchar(255) DEFAULT '' NOT NULL,
        country varchar(100) DEFAULT '' NOT NULL,
        region varchar(100) DEFAULT '' NOT NULL,
        city varchar(100) DEFAULT '' NOT NULL,
        lat decimal(10,8) DEFAULT NULL,
        lon decimal(11,8) DEFAULT NULL,
        device_type varchar(20) DEFAULT '' NOT NULL,
        browser varchar(100) DEFAULT '' NOT NULL,
        os varchar(100) DEFAULT '' NOT NULL,
        referer text DEFAULT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'my_create_search_logs_table');


// 2. Add admin menu for viewing logs
function my_register_search_logs_page() {
    add_menu_page(
        'Search History',
        'Search Logs',
        'manage_options',
        'search-logs',
        'my_display_search_logs',
        'dashicons-search',
        25
    );
}
add_action('admin_menu', 'my_register_search_logs_page');


// 3. Display logs in admin page
function my_display_search_logs()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'search_logs';
    $results = $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC");

    echo '<div class="wrap"><h1>Search Logs</h1>';
    echo '<table class="widefat striped">';
    echo '<thead><tr><th>Term</th><th>IP</th><th>Country</th><th>City</th><th>Date</th></tr></thead><tbody>';

    if ($results) {
        foreach ($results as $row) {
            echo '<tr>';
            echo '<td>' . esc_html($row->search_term) . '</td>';
            echo '<td>' . esc_html($row->ip_address) . '</td>';
            echo '<td>' . esc_html($row->country) . '</td>';
            echo '<td>' . esc_html($row->city) . '</td>';
            echo '<td>' . esc_html($row->created_at) . '</td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="5">No search logs found.</td></tr>';
    }

    echo '</tbody></table></div>';
}

// 4. Log search data
function my_log_search_data() {
    if (is_search() && isset($_GET['s'])) {
        global $wpdb;

        $search_term = sanitize_text_field($_GET['s']);
        $search_slug = sanitize_title($search_term);
        $ip          = $_SERVER['REMOTE_ADDR'];
        $user_id     = get_current_user_id();
        $user_name   = $user_id ? wp_get_current_user()->display_name : '';

        // Device & Browser Detection
        $user_agent  = $_SERVER['HTTP_USER_AGENT'];
        $device_type = wp_is_mobile() ? 'Mobile' : 'Desktop';
        $browser     = 'Unknown';
        $os          = 'Unknown';

        if (preg_match('/Windows/i', $user_agent)) $os = 'Windows';
        elseif (preg_match('/Mac/i', $user_agent)) $os = 'MacOS';
        elseif (preg_match('/Linux/i', $user_agent)) $os = 'Linux';
        elseif (preg_match('/Android/i', $user_agent)) $os = 'Android';
        elseif (preg_match('/iPhone|iPad/i', $user_agent)) $os = 'iOS';

        if (preg_match('/Chrome/i', $user_agent)) $browser = 'Chrome';
        elseif (preg_match('/Safari/i', $user_agent) && !preg_match('/Chrome/i', $user_agent)) $browser = 'Safari';
        elseif (preg_match('/Firefox/i', $user_agent)) $browser = 'Firefox';
        elseif (preg_match('/Edge/i', $user_agent)) $browser = 'Edge';
        elseif (preg_match('/MSIE|Trident/i', $user_agent)) $browser = 'Internet Explorer';

        // Get location
        $country = $region = $city = '';
        $lat = $lon = null;

        $location_data = wp_remote_get("http://ip-api.com/json/{$ip}");
        if (!is_wp_error($location_data)) {
            $body = json_decode(wp_remote_retrieve_body($location_data));
            if ($body && $body->status === 'success') {
                $country = sanitize_text_field($body->country);
                $region  = sanitize_text_field($body->regionName);
                $city    = sanitize_text_field($body->city);
                $lat     = floatval($body->lat);
                $lon     = floatval($body->lon);
            }
        }

        // Save
        $wpdb->insert(
            "{$wpdb->prefix}search_logs",
            array(
                'search_term' => $search_term,
                'search_slug' => $search_slug,
                'ip_address'  => $ip,
                'user_id'     => $user_id,
                'user_name'   => $user_name,
                'country'     => $country,
                'region'      => $region,
                'city'        => $city,
                'lat'         => $lat,
                'lon'         => $lon,
                'device_type' => $device_type,
                'browser'     => $browser,
                'os'          => $os,
                'referer'     => isset($_SERVER['HTTP_REFERER']) ? esc_url_raw($_SERVER['HTTP_REFERER']) : '',
                'created_at'  => current_time('mysql'),
            ),
            array('%s','%s','%s','%d','%s','%s','%s','%s','%f','%f','%s','%s','%s','%s','%s','%s')
        );
    }
}
add_action('template_redirect', 'my_log_search_data');
 
